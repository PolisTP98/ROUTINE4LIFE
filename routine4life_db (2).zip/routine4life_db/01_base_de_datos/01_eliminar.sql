USE master;
GO

IF EXISTS (SELECT 1 FROM sys.databases WHERE name = 'routine4life')
BEGIN
    ALTER DATABASE routine4life SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE routine4life;
END
GO