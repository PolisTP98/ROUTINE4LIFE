/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 01/11/2025.
-	Fecha de la �ltima actualizaci�n: 01/11/2025.
-	T�tulo: Crear esquemas.
-	Descripci�n: En este archivo se crean los esquemas a utilizar en la base de datos.

==========================================================================================================================================================
*/


GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'r4l')
BEGIN
    EXEC('CREATE SCHEMA r4l');
END;
GO