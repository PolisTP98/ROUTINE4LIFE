/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 01/11/2025.
-	Fecha de la �ltima actualizaci�n: 04/11/2025.
-	T�tulo: Crear base de datos.
-	Descripci�n: En este archivo se crea y usa la base de datos "routine4life".

==========================================================================================================================================================
*/


GO
IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'routine4life')
BEGIN
    CREATE DATABASE routine4life;
END
GO

GO
USE routine4life;
SELECT DB_NAME() AS BaseActual;
GO