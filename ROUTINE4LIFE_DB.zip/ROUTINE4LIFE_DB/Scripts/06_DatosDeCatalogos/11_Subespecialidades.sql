/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 06/11/2025.
-	Fecha de la �ltima actualizaci�n: 07/11/2025.
-	T�tulo: Datos de cat�logo.
-	Descripci�n: En este archivo se insertan los datos de la tabla cat�logo "subespecialidades".

==========================================================================================================================================================
*/


GO
-- Alergolog�a (1)
EXEC r4l.sp_insert_subespecialidad 1, 'Alergia e Inmunolog�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 1, 'Alergia Respiratoria';
EXEC r4l.sp_insert_subespecialidad 1, 'Alergia Pedi�trica';

-- Anestesiolog�a (2)
EXEC r4l.sp_insert_subespecialidad 2, 'Anestesia Cardiovascular';
EXEC r4l.sp_insert_subespecialidad 2, 'Anestesia Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 2, 'Anestesia Obst�trica';
EXEC r4l.sp_insert_subespecialidad 2, 'Anestesia Regional y del Dolor';

-- Angiolog�a (3)
EXEC r4l.sp_insert_subespecialidad 3, 'Cirug�a Endovascular';
EXEC r4l.sp_insert_subespecialidad 3, 'Flebolog�a';
EXEC r4l.sp_insert_subespecialidad 3, 'Linfolog�a';

-- Cardiolog�a (4)
EXEC r4l.sp_insert_subespecialidad 4, 'Cardiolog�a Intervencionista';
EXEC r4l.sp_insert_subespecialidad 4, 'Electrofisiolog�a';
EXEC r4l.sp_insert_subespecialidad 4, 'Cardiolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 4, 'Ecocardiograf�a';

-- Cirug�a general (5)
EXEC r4l.sp_insert_subespecialidad 5, 'Cirug�a Laparosc�pica';
EXEC r4l.sp_insert_subespecialidad 5, 'Cirug�a Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 5, 'Cirug�a de Trauma y Urgencias';

-- Cirug�a pl�stica y reconstructiva (6)
EXEC r4l.sp_insert_subespecialidad 6, 'Cirug�a Est�tica';
EXEC r4l.sp_insert_subespecialidad 6, 'Cirug�a Reconstructiva';
EXEC r4l.sp_insert_subespecialidad 6, 'Microcirug�a';

-- Cirug�a tor�cica (7)
EXEC r4l.sp_insert_subespecialidad 7, 'Cirug�a de Pulm�n';
EXEC r4l.sp_insert_subespecialidad 7, 'Cirug�a Esof�gica';
EXEC r4l.sp_insert_subespecialidad 7, 'Cirug�a Mediastinal';

-- Cirug�a vascular (8)
EXEC r4l.sp_insert_subespecialidad 8, 'Cirug�a Arterial';
EXEC r4l.sp_insert_subespecialidad 8, 'Cirug�a Venosa';
EXEC r4l.sp_insert_subespecialidad 8, 'Angioplastia';

-- Dermatolog�a (9)
EXEC r4l.sp_insert_subespecialidad 9, 'Dermatolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 9, 'Dermatopatolog�a';
EXEC r4l.sp_insert_subespecialidad 9, 'Dermatooncolog�a';
EXEC r4l.sp_insert_subespecialidad 9, 'Tricolog�a';

-- Endocrinolog�a (10)
EXEC r4l.sp_insert_subespecialidad 10, 'Endocrinolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 10, 'Diabetolog�a';
EXEC r4l.sp_insert_subespecialidad 10, 'Neuroendocrinolog�a';

-- Epidemiolog�a (11)
EXEC r4l.sp_insert_subespecialidad 11, 'Epidemiolog�a Hospitalaria';
EXEC r4l.sp_insert_subespecialidad 11, 'Epidemiolog�a de Campo';
EXEC r4l.sp_insert_subespecialidad 11, 'Epidemiolog�a Molecular';

-- Gastroenterolog�a (12)
EXEC r4l.sp_insert_subespecialidad 12, 'Endoscop�a Digestiva';
EXEC r4l.sp_insert_subespecialidad 12, 'Hepatolog�a';
EXEC r4l.sp_insert_subespecialidad 12, 'Gastroenterolog�a Pedi�trica';

-- Geriatr�a (13)
EXEC r4l.sp_insert_subespecialidad 13, 'Geriatr�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 13, 'Medicina Paliativa del Adulto Mayor';
EXEC r4l.sp_insert_subespecialidad 13, 'Neurogeriatr�a';

-- Ginecolog�a y obstetricia (14)
EXEC r4l.sp_insert_subespecialidad 14, 'Medicina Materno Fetal';
EXEC r4l.sp_insert_subespecialidad 14, 'Ginecolog�a Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 14, 'Biolog�a de la Reproducci�n Humana';
EXEC r4l.sp_insert_subespecialidad 14, 'Uroginecolog�a';

-- Hematolog�a (15)
EXEC r4l.sp_insert_subespecialidad 15, 'Hematolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 15, 'Hemostasia y Trombosis';
EXEC r4l.sp_insert_subespecialidad 15, 'Oncohematolog�a';

-- Infectolog�a (16)
EXEC r4l.sp_insert_subespecialidad 16, 'Infectolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 16, 'Infecciones Nosocomiales';
EXEC r4l.sp_insert_subespecialidad 16, 'Infecciones Tropicales';

-- Medicina del deporte (17)
EXEC r4l.sp_insert_subespecialidad 17, 'Traumatolog�a Deportiva';
EXEC r4l.sp_insert_subespecialidad 17, 'Rehabilitaci�n Deportiva';
EXEC r4l.sp_insert_subespecialidad 17, 'Nutrici�n Deportiva';

-- Medicina de urgencias (18)
EXEC r4l.sp_insert_subespecialidad 18, 'Emergencias Cardiovasculares';
EXEC r4l.sp_insert_subespecialidad 18, 'Emergencias Pedi�tricas';
EXEC r4l.sp_insert_subespecialidad 18, 'Medicina de Desastres';

-- Medicina familiar (19)
EXEC r4l.sp_insert_subespecialidad 19, 'Salud Comunitaria';
EXEC r4l.sp_insert_subespecialidad 19, 'Atenci�n Integral del Adulto Mayor';
EXEC r4l.sp_insert_subespecialidad 19, 'Medicina Preventiva Familiar';

-- Medicina f�sica y rehabilitaci�n (20)
EXEC r4l.sp_insert_subespecialidad 20, 'Rehabilitaci�n Neurol�gica';
EXEC r4l.sp_insert_subespecialidad 20, 'Rehabilitaci�n Musculoesquel�tica';
EXEC r4l.sp_insert_subespecialidad 20, 'Rehabilitaci�n Pedi�trica';

-- Medicina interna (21)
EXEC r4l.sp_insert_subespecialidad 21, 'Nefrolog�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 21, 'Endocrinolog�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 21, 'Reumatolog�a Cl�nica';

-- Nefrolog�a (22)
EXEC r4l.sp_insert_subespecialidad 22, 'Nefrolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 22, 'Trasplante Renal';
EXEC r4l.sp_insert_subespecialidad 22, 'Di�lisis y Hemodi�lisis';

-- Neonatolog�a (23)
EXEC r4l.sp_insert_subespecialidad 23, 'Cuidado Intensivo Neonatal';
EXEC r4l.sp_insert_subespecialidad 23, 'Nutrici�n Neonatal';
EXEC r4l.sp_insert_subespecialidad 23, 'Reanimaci�n Neonatal';

-- Neumolog�a (24)
EXEC r4l.sp_insert_subespecialidad 24, 'Neumolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 24, 'Medicina del Sue�o';
EXEC r4l.sp_insert_subespecialidad 24, 'Broncoscop�a';

-- Neurolog�a (25)
EXEC r4l.sp_insert_subespecialidad 25, 'Neurolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 25, 'Neurofisiolog�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 25, 'Epileptolog�a';
EXEC r4l.sp_insert_subespecialidad 25, 'Cefaleas y Dolor Neurol�gico';

-- Neurocirug�a (26)
EXEC r4l.sp_insert_subespecialidad 26, 'Neurocirug�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 26, 'Neurocirug�a Vascular';
EXEC r4l.sp_insert_subespecialidad 26, 'Neurocirug�a Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 26, 'Columna y Nervio Perif�rico';

-- Nutriolog�a (27)
EXEC r4l.sp_insert_subespecialidad 27, 'Nutrici�n Cl�nica';
EXEC r4l.sp_insert_subespecialidad 27, 'Nutrici�n Parenteral y Enteral';
EXEC r4l.sp_insert_subespecialidad 27, 'Nutrici�n Comunitaria';

-- Odontolog�a (28)
EXEC r4l.sp_insert_subespecialidad 28, 'Endodoncia';
EXEC r4l.sp_insert_subespecialidad 28, 'Periodoncia';
EXEC r4l.sp_insert_subespecialidad 28, 'Ortodoncia';
EXEC r4l.sp_insert_subespecialidad 28, 'Odontopediatr�a';

-- Oftalmolog�a (29)
EXEC r4l.sp_insert_subespecialidad 29, 'Oftalmolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 29, 'Retina y V�treo';
EXEC r4l.sp_insert_subespecialidad 29, 'Glaucoma';
EXEC r4l.sp_insert_subespecialidad 29, 'C�rnea y Cirug�a Refractiva';

-- Oncolog�a m�dica (30)
EXEC r4l.sp_insert_subespecialidad 30, 'Oncolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 30, 'Tumores S�lidos';
EXEC r4l.sp_insert_subespecialidad 30, 'Hematolog�a Oncol�gica';

-- Otorrinolaringolog�a (31)
EXEC r4l.sp_insert_subespecialidad 31, 'Otolog�a y Neurotolog�a';
EXEC r4l.sp_insert_subespecialidad 31, 'Rinolog�a y Cirug�a Endosc�pica';
EXEC r4l.sp_insert_subespecialidad 31, 'Laringolog�a';
EXEC r4l.sp_insert_subespecialidad 31, 'Otorrinolaringolog�a Pedi�trica';

-- Pediatr�a (32)
EXEC r4l.sp_insert_subespecialidad 32, 'Pediatr�a de Urgencias';
EXEC r4l.sp_insert_subespecialidad 32, 'Pediatr�a del Desarrollo';
EXEC r4l.sp_insert_subespecialidad 32, 'Pediatr�a Intensiva';

-- Psiquiatr�a (33)
EXEC r4l.sp_insert_subespecialidad 33, 'Psiquiatr�a Infantil y Adolescente';
EXEC r4l.sp_insert_subespecialidad 33, 'Psiquiatr�a Geri�trica';
EXEC r4l.sp_insert_subespecialidad 33, 'Psiquiatr�a de Enlace';
EXEC r4l.sp_insert_subespecialidad 33, 'Psiquiatr�a Forense';

-- Radiolog�a (34)
EXEC r4l.sp_insert_subespecialidad 34, 'Neurorradiolog�a';
EXEC r4l.sp_insert_subespecialidad 34, 'Radiolog�a Intervencionista';
EXEC r4l.sp_insert_subespecialidad 34, 'Radiolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 34, 'Imagen Mamaria';

-- Reumatolog�a (35)
EXEC r4l.sp_insert_subespecialidad 35, 'Reumatolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 35, 'Enfermedades Autoinmunes';
EXEC r4l.sp_insert_subespecialidad 35, 'Reumatolog�a Cl�nica Avanzada';

-- Traumatolog�a y ortopedia (36)
EXEC r4l.sp_insert_subespecialidad 36, 'Ortopedia Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 36, 'Artroscop�a';
EXEC r4l.sp_insert_subespecialidad 36, 'Columna Vertebral';
EXEC r4l.sp_insert_subespecialidad 36, 'Reemplazos Articulares';

-- Urolog�a (37)
EXEC r4l.sp_insert_subespecialidad 37, 'Urolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 37, 'Urolog�a Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 37, 'Endourolog�a y Laparoscop�a';

-- Medicina cr�tica (38)
EXEC r4l.sp_insert_subespecialidad 38, 'Terapia Intensiva Adultos';
EXEC r4l.sp_insert_subespecialidad 38, 'Terapia Intensiva Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 38, 'Terapia Intensiva Cardiovascular';

-- Anatom�a patol�gica (39)
EXEC r4l.sp_insert_subespecialidad 39, 'Patolog�a Quir�rgica';
EXEC r4l.sp_insert_subespecialidad 39, 'Citopatolog�a';
EXEC r4l.sp_insert_subespecialidad 39, 'Patolog�a Molecular';

-- Cirug�a cardiovascular (40)
EXEC r4l.sp_insert_subespecialidad 40, 'Cirug�a Cardiaca Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 40, 'Cirug�a Coronaria';
EXEC r4l.sp_insert_subespecialidad 40, 'Cirug�a Valvular';
EXEC r4l.sp_insert_subespecialidad 40, 'Cirug�a A�rtica';

-- Cirug�a maxilofacial (41)
EXEC r4l.sp_insert_subespecialidad 41, 'Cirug�a Ortogn�tica';
EXEC r4l.sp_insert_subespecialidad 41, 'Trauma Maxilofacial';
EXEC r4l.sp_insert_subespecialidad 41, 'Cirug�a Reconstructiva Facial';

-- Cirug�a pedi�trica (42)
EXEC r4l.sp_insert_subespecialidad 42, 'Cirug�a Neonatal';
EXEC r4l.sp_insert_subespecialidad 42, 'Cirug�a Gastrointestinal Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 42, 'Cirug�a Tor�cica Pedi�trica';

-- Cirug�a oncol�gica (43)
EXEC r4l.sp_insert_subespecialidad 43, 'Oncolog�a Quir�rgica Gastrointestinal';
EXEC r4l.sp_insert_subespecialidad 43, 'Oncolog�a Quir�rgica de Mama';
EXEC r4l.sp_insert_subespecialidad 43, 'Sarcomas y Tejidos Blandos';

-- Cirug�a neurol�gica (44)
EXEC r4l.sp_insert_subespecialidad 44, 'Neurocirug�a Funcional';
EXEC r4l.sp_insert_subespecialidad 44, 'Neurocirug�a Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 44, 'Neurocirug�a de Columna';

-- Cirug�a de cabeza y cuello (45)
EXEC r4l.sp_insert_subespecialidad 45, 'Oncolog�a de Cabeza y Cuello';
EXEC r4l.sp_insert_subespecialidad 45, 'Cirug�a Endocrina (Tiroides/Paratiroides)';
EXEC r4l.sp_insert_subespecialidad 45, 'Cirug�a Reconstructiva de Cuello';

-- Cirug�a de mano (46)
EXEC r4l.sp_insert_subespecialidad 46, 'Microcirug�a de Mano';
EXEC r4l.sp_insert_subespecialidad 46, 'Cirug�a de Nervio Perif�rico';
EXEC r4l.sp_insert_subespecialidad 46, 'Trauma de Mano';

-- Cirug�a bari�trica (47)
EXEC r4l.sp_insert_subespecialidad 47, 'Cirug�a Metab�lica';
EXEC r4l.sp_insert_subespecialidad 47, 'Cirug�a Laparosc�pica Bari�trica';

-- Coloproctolog�a (48)
EXEC r4l.sp_insert_subespecialidad 48, 'Cirug�a Colorrectal';
EXEC r4l.sp_insert_subespecialidad 48, 'Proctolog�a Avanzada';
EXEC r4l.sp_insert_subespecialidad 48, 'Enfermedad Inflamatoria Intestinal';

-- Angiolog�a y cirug�a vascular (49)
EXEC r4l.sp_insert_subespecialidad 49, 'Cirug�a Endovascular';
EXEC r4l.sp_insert_subespecialidad 49, 'Flebolog�a';
EXEC r4l.sp_insert_subespecialidad 49, 'Linfolog�a';

-- Medicina nuclear (50)
EXEC r4l.sp_insert_subespecialidad 50, 'PET/CT';
EXEC r4l.sp_insert_subespecialidad 50, 'Terapia con Radiois�topos';
EXEC r4l.sp_insert_subespecialidad 50, 'Imagen Molecular';

-- Dermatopatolog�a (51)
EXEC r4l.sp_insert_subespecialidad 51, 'Dermatopatolog�a Quir�rgica';
EXEC r4l.sp_insert_subespecialidad 51, 'Dermatopatolog�a Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 51, 'Micolog�a M�dica';

-- Foniatr�a (52)
EXEC r4l.sp_insert_subespecialidad 52, 'Foniatr�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 52, 'Rehabilitaci�n de la Voz';
EXEC r4l.sp_insert_subespecialidad 52, 'Trastornos del Lenguaje y Comunicaci�n';

-- Gastroenterolog�a pedi�trica (53)
EXEC r4l.sp_insert_subespecialidad 53, 'Nutrici�n Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 53, 'Hepatolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 53, 'Gastroenterolog�a Endosc�pica Pedi�trica';

-- Ginecolog�a oncol�gica (54)
EXEC r4l.sp_insert_subespecialidad 54, 'Cirug�a Oncol�gica Ginecol�gica';
EXEC r4l.sp_insert_subespecialidad 54, 'Oncolog�a de Mama';
EXEC r4l.sp_insert_subespecialidad 54, 'Oncolog�a Reproductiva';

-- Hepatolog�a (55)
EXEC r4l.sp_insert_subespecialidad 55, 'Trasplante Hep�tico';
EXEC r4l.sp_insert_subespecialidad 55, 'Hepatolog�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 55, 'Enfermedad Hep�tica Autoinmune';

-- Inmunolog�a cl�nica (56)
EXEC r4l.sp_insert_subespecialidad 56, 'Alergia e Inmunolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 56, 'Inmunodeficiencias Primarias';
EXEC r4l.sp_insert_subespecialidad 56, 'Autoinmunidad Cl�nica';

-- Medicina cr�tica (57)
EXEC r4l.sp_insert_subespecialidad 57, 'Terapia Intensiva Respiratoria';
EXEC r4l.sp_insert_subespecialidad 57, 'Shock y Sepsis';
EXEC r4l.sp_insert_subespecialidad 57, 'Cuidados Intensivos Neurol�gicos';

-- Medicina del sue�o (58)
EXEC r4l.sp_insert_subespecialidad 58, 'Trastornos Respiratorios del Sue�o';
EXEC r4l.sp_insert_subespecialidad 58, 'Insomnio y Cronobiolog�a';
EXEC r4l.sp_insert_subespecialidad 58, 'Narcolepsia y Trastornos Neurol�gicos del Sue�o';

-- Medicina forense (59)
EXEC r4l.sp_insert_subespecialidad 59, 'Tanatolog�a Forense';
EXEC r4l.sp_insert_subespecialidad 59, 'Criminal�stica M�dica';
EXEC r4l.sp_insert_subespecialidad 59, 'Toxicolog�a Forense';

-- Medicina paliativa (60)
EXEC r4l.sp_insert_subespecialidad 60, 'Cuidados Paliativos Pedi�tricos';
EXEC r4l.sp_insert_subespecialidad 60, 'Control del Dolor';
EXEC r4l.sp_insert_subespecialidad 60, 'Paliaci�n Oncol�gica Avanzada';

-- Medicina tropical (61)
EXEC r4l.sp_insert_subespecialidad 61, 'Parasitolog�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 61, 'Enfermedades Transmitidas por Vectores';
EXEC r4l.sp_insert_subespecialidad 61, 'Epidemiolog�a Tropical';

-- Microbiolog�a (62)
EXEC r4l.sp_insert_subespecialidad 62, 'Bacteriolog�a Cl�nica';
EXEC r4l.sp_insert_subespecialidad 62, 'Virolog�a M�dica';
EXEC r4l.sp_insert_subespecialidad 62, 'Micolog�a Cl�nica';

-- Neurofisiolog�a cl�nica (63)
EXEC r4l.sp_insert_subespecialidad 63, 'Electroencefalograf�a Avanzada';
EXEC r4l.sp_insert_subespecialidad 63, 'Electromiograf�a y Conducci�n Nerviosa';
EXEC r4l.sp_insert_subespecialidad 63, 'Monitoreo Neurofisiol�gico Intraoperatorio';

-- Neuropediatr�a (64)
EXEC r4l.sp_insert_subespecialidad 64, 'Neurometab�licas y Enfermedades Raras';
EXEC r4l.sp_insert_subespecialidad 64, 'Epileptolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 64, 'Neurodesarrollo';

-- Oncohematolog�a (65)
EXEC r4l.sp_insert_subespecialidad 65, 'Leucemias y Linfomas';
EXEC r4l.sp_insert_subespecialidad 65, 'Trasplante de M�dula �sea';
EXEC r4l.sp_insert_subespecialidad 65, 'Hemato-Oncolog�a Pedi�trica';

-- Oncolog�a radioter�pica (66)
EXEC r4l.sp_insert_subespecialidad 66, 'Radioterapia Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 66, 'Radioterapia de Alta Precisi�n';
EXEC r4l.sp_insert_subespecialidad 66, 'Braquiterapia Oncol�gica';

-- Otoneurolog�a (67)
EXEC r4l.sp_insert_subespecialidad 67, 'V�rtigo y Trastornos del Equilibrio';
EXEC r4l.sp_insert_subespecialidad 67, 'Hipoacusia y Audici�n';
EXEC r4l.sp_insert_subespecialidad 67, 'Trastornos Vestibulares Centrales';

-- Patolog�a cl�nica (68)
EXEC r4l.sp_insert_subespecialidad 68, 'Hematopatolog�a';
EXEC r4l.sp_insert_subespecialidad 68, 'Biolog�a Molecular Diagn�stica';
EXEC r4l.sp_insert_subespecialidad 68, 'Inmunopatolog�a';

-- Psicolog�a m�dica (69)
EXEC r4l.sp_insert_subespecialidad 69, 'Psicolog�a de la Salud';
EXEC r4l.sp_insert_subespecialidad 69, 'Psicooncolog�a';
EXEC r4l.sp_insert_subespecialidad 69, 'Psicolog�a Hospitalaria';

-- Rehabilitaci�n neurol�gica (70)
EXEC r4l.sp_insert_subespecialidad 70, 'Rehabilitaci�n de Lesiones Medulares';
EXEC r4l.sp_insert_subespecialidad 70, 'Rehabilitaci�n Post-Ictus';
EXEC r4l.sp_insert_subespecialidad 70, 'Rehabilitaci�n Neurocognitiva';

-- Reumatolog�a pedi�trica (71)
EXEC r4l.sp_insert_subespecialidad 71, 'Enfermedades Autoinmunes Pedi�tricas';
EXEC r4l.sp_insert_subespecialidad 71, 'Artritis Idiop�tica Juvenil';
EXEC r4l.sp_insert_subespecialidad 71, 'Vasculitis Pedi�tricas';

-- Toxicolog�a cl�nica (72)
EXEC r4l.sp_insert_subespecialidad 72, 'Toxicolog�a de Urgencias';
EXEC r4l.sp_insert_subespecialidad 72, 'Toxicolog�a Ambiental y Laboral';
EXEC r4l.sp_insert_subespecialidad 72, 'Toxicolog�a Farmacol�gica';

-- Traumatolog�a deportiva (73)
EXEC r4l.sp_insert_subespecialidad 73, 'Lesiones de Rodilla y Hombro';
EXEC r4l.sp_insert_subespecialidad 73, 'Medicina del Deporte Quir�rgica';
EXEC r4l.sp_insert_subespecialidad 73, 'Rehabilitaci�n Deportiva Avanzada';

-- Urolog�a pedi�trica (74)
EXEC r4l.sp_insert_subespecialidad 74, 'Malformaciones Genitourinarias';
EXEC r4l.sp_insert_subespecialidad 74, 'Endourolog�a Pedi�trica';
EXEC r4l.sp_insert_subespecialidad 74, 'Oncolog�a Urol�gica Pedi�trica';

-- Medicina aeroespacial (75)
EXEC r4l.sp_insert_subespecialidad 75, 'Medicina del Vuelo';
EXEC r4l.sp_insert_subespecialidad 75, 'Fisiolog�a Aeroespacial';
EXEC r4l.sp_insert_subespecialidad 75, 'Medicina de Altura';

-- Medicina hiperb�rica (76)
EXEC r4l.sp_insert_subespecialidad 76, 'Tratamiento con Ox�geno Hiperb�rico';
EXEC r4l.sp_insert_subespecialidad 76, 'Lesiones por Descompresi�n';
EXEC r4l.sp_insert_subespecialidad 76, 'Cicatrizaci�n y Manejo de Heridas Complejas';

-- Medicina del dolor (77)
EXEC r4l.sp_insert_subespecialidad 77, 'Manejo Intervencionista del Dolor';
EXEC r4l.sp_insert_subespecialidad 77, 'Dolor Cr�nico Complejo';
EXEC r4l.sp_insert_subespecialidad 77, 'Cuidados Paliativos y Dolor Avanzado';

-- Bio�tica m�dica (78)
EXEC r4l.sp_insert_subespecialidad 78, '�tica Cl�nica';
EXEC r4l.sp_insert_subespecialidad 78, 'Comit�s Hospitalarios de Bio�tica';
EXEC r4l.sp_insert_subespecialidad 78, '�tica en Investigaci�n M�dica';

-- Telemedicina (79)
EXEC r4l.sp_insert_subespecialidad 79, 'Teleconsulta Cl�nica';
EXEC r4l.sp_insert_subespecialidad 79, 'Teleradiolog�a';
EXEC r4l.sp_insert_subespecialidad 79, 'Telemonitoreo de Pacientes Cr�nicos';

-- Salud ocupacional (80)
EXEC r4l.sp_insert_subespecialidad 80, 'Higiene Industrial';
EXEC r4l.sp_insert_subespecialidad 80, 'Ergonom�a y Biomec�nica Laboral';
EXEC r4l.sp_insert_subespecialidad 80, 'Toxicolog�a Laboral';

-- Medicina familiar y comunitaria (81)
EXEC r4l.sp_insert_subespecialidad 81, 'Atenci�n Primaria Avanzada';
EXEC r4l.sp_insert_subespecialidad 81, 'Salud Comunitaria';
EXEC r4l.sp_insert_subespecialidad 81, 'Medicina Preventiva Familiar';

-- Cirug�a de trasplantes (82)
EXEC r4l.sp_insert_subespecialidad 82, 'Trasplante Renal';
EXEC r4l.sp_insert_subespecialidad 82, 'Trasplante Hep�tico';
EXEC r4l.sp_insert_subespecialidad 82, 'Trasplante Cardiaco';

-- Cirug�a ortop�dica (83)
EXEC r4l.sp_insert_subespecialidad 83, 'Cirug�a de Reemplazo Articular';
EXEC r4l.sp_insert_subespecialidad 83, 'Ortopedia Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 83, 'Trauma Ortop�dico Complejo';

-- Cirug�a laparosc�pica (84)
EXEC r4l.sp_insert_subespecialidad 84, 'Laparoscop�a Bari�trica';
EXEC r4l.sp_insert_subespecialidad 84, 'Laparoscop�a Oncol�gica';
EXEC r4l.sp_insert_subespecialidad 84, 'Cirug�a M�nimamente Invasiva Avanzada';
GO