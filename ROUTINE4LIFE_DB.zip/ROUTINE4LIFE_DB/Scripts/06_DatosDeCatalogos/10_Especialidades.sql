/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 06/11/2025.
-	Fecha de la �ltima actualizaci�n: 07/11/2025.
-	T�tulo: Datos de cat�logo.
-	Descripci�n: En este archivo se insertan los datos de la tabla cat�logo "especialidades".

==========================================================================================================================================================
*/


GO
EXEC r4l.sp_insert_especialidad 'Alergolog�a';
EXEC r4l.sp_insert_especialidad 'Anestesiolog�a';
EXEC r4l.sp_insert_especialidad 'Angiolog�a';
EXEC r4l.sp_insert_especialidad 'Cardiolog�a';
EXEC r4l.sp_insert_especialidad 'Cirug�a general';
EXEC r4l.sp_insert_especialidad 'Cirug�a pl�stica y reconstructiva';
EXEC r4l.sp_insert_especialidad 'Cirug�a tor�cica';
EXEC r4l.sp_insert_especialidad 'Cirug�a vascular';
EXEC r4l.sp_insert_especialidad 'Dermatolog�a';
EXEC r4l.sp_insert_especialidad 'Endocrinolog�a';
EXEC r4l.sp_insert_especialidad 'Epidemiolog�a';
EXEC r4l.sp_insert_especialidad 'Gastroenterolog�a';
EXEC r4l.sp_insert_especialidad 'Geriatr�a';
EXEC r4l.sp_insert_especialidad 'Ginecolog�a y obstetricia';
EXEC r4l.sp_insert_especialidad 'Hematolog�a';
EXEC r4l.sp_insert_especialidad 'Infectolog�a';
EXEC r4l.sp_insert_especialidad 'Medicina del deporte';
EXEC r4l.sp_insert_especialidad 'Medicina de urgencias';
EXEC r4l.sp_insert_especialidad 'Medicina familiar';
EXEC r4l.sp_insert_especialidad 'Medicina f�sica y rehabilitaci�n';
EXEC r4l.sp_insert_especialidad 'Medicina interna';
EXEC r4l.sp_insert_especialidad 'Nefrolog�a';
EXEC r4l.sp_insert_especialidad 'Neonatolog�a';
EXEC r4l.sp_insert_especialidad 'Neumolog�a';
EXEC r4l.sp_insert_especialidad 'Neurolog�a';
EXEC r4l.sp_insert_especialidad 'Nutriolog�a';
EXEC r4l.sp_insert_especialidad 'Oftalmolog�a';
EXEC r4l.sp_insert_especialidad 'Oncolog�a';
EXEC r4l.sp_insert_especialidad 'Otorrinolaringolog�a';
EXEC r4l.sp_insert_especialidad 'Pediatr�a';
EXEC r4l.sp_insert_especialidad 'Psiquiatr�a';
EXEC r4l.sp_insert_especialidad 'Radiolog�a';
EXEC r4l.sp_insert_especialidad 'Reumatolog�a';
EXEC r4l.sp_insert_especialidad 'Traumatolog�a y ortopedia';
EXEC r4l.sp_insert_especialidad 'Urolog�a';
EXEC r4l.sp_insert_especialidad 'Patolog�a';
EXEC r4l.sp_insert_especialidad 'Medicina laboral';
EXEC r4l.sp_insert_especialidad 'Medicina preventiva';
EXEC r4l.sp_insert_especialidad 'Terapia intensiva';
EXEC r4l.sp_insert_especialidad 'Salud p�blica';
EXEC r4l.sp_insert_especialidad 'Medicina nuclear';
EXEC r4l.sp_insert_especialidad 'Gen�tica m�dica';
EXEC r4l.sp_insert_especialidad 'Anatom�a patol�gica';
EXEC r4l.sp_insert_especialidad 'Cirug�a cardiovascular';
EXEC r4l.sp_insert_especialidad 'Cirug�a maxilofacial';
EXEC r4l.sp_insert_especialidad 'Cirug�a pedi�trica';
EXEC r4l.sp_insert_especialidad 'Cirug�a oncol�gica';
EXEC r4l.sp_insert_especialidad 'Cirug�a neurol�gica';
EXEC r4l.sp_insert_especialidad 'Cirug�a de cabeza y cuello';
EXEC r4l.sp_insert_especialidad 'Cirug�a de mano';
EXEC r4l.sp_insert_especialidad 'Cirug�a de trasplantes';
EXEC r4l.sp_insert_especialidad 'Cirug�a ortop�dica';
EXEC r4l.sp_insert_especialidad 'Cirug�a laparosc�pica';
EXEC r4l.sp_insert_especialidad 'Dermatopatolog�a';
EXEC r4l.sp_insert_especialidad 'Foniatr�a';
EXEC r4l.sp_insert_especialidad 'Gastroenterolog�a pedi�trica';
EXEC r4l.sp_insert_especialidad 'Ginecolog�a oncol�gica';
EXEC r4l.sp_insert_especialidad 'Hepatolog�a';
EXEC r4l.sp_insert_especialidad 'Inmunolog�a cl�nica';
EXEC r4l.sp_insert_especialidad 'Medicina cr�tica';
EXEC r4l.sp_insert_especialidad 'Medicina del sue�o';
EXEC r4l.sp_insert_especialidad 'Medicina forense';
EXEC r4l.sp_insert_especialidad 'Medicina paliativa';
EXEC r4l.sp_insert_especialidad 'Medicina tropical';
EXEC r4l.sp_insert_especialidad 'Microbiolog�a';
EXEC r4l.sp_insert_especialidad 'Neurocirug�a';
EXEC r4l.sp_insert_especialidad 'Neurofisiolog�a cl�nica';
EXEC r4l.sp_insert_especialidad 'Neuropediatr�a';
EXEC r4l.sp_insert_especialidad 'Oncohematolog�a';
EXEC r4l.sp_insert_especialidad 'Oncolog�a radioter�pica';
EXEC r4l.sp_insert_especialidad 'Otoneurolog�a';
EXEC r4l.sp_insert_especialidad 'Patolog�a cl�nica';
EXEC r4l.sp_insert_especialidad 'Psicolog�a m�dica';
EXEC r4l.sp_insert_especialidad 'Rehabilitaci�n neurol�gica';
EXEC r4l.sp_insert_especialidad 'Reumatolog�a pedi�trica';
EXEC r4l.sp_insert_especialidad 'Toxicolog�a cl�nica';
EXEC r4l.sp_insert_especialidad 'Traumatolog�a deportiva';
EXEC r4l.sp_insert_especialidad 'Urolog�a pedi�trica';
EXEC r4l.sp_insert_especialidad 'Medicina aeroespacial';
EXEC r4l.sp_insert_especialidad 'Medicina hiperb�rica';
EXEC r4l.sp_insert_especialidad 'Medicina del dolor';
EXEC r4l.sp_insert_especialidad 'Bio�tica m�dica';
EXEC r4l.sp_insert_especialidad 'Telemedicina';
EXEC r4l.sp_insert_especialidad 'Salud ocupacional';
EXEC r4l.sp_insert_especialidad 'Medicina familiar y comunitaria';
GO