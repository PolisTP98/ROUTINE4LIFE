/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 06/11/2025.
-	Fecha de la �ltima actualizaci�n: 07/11/2025.
-	T�tulo: Datos de cat�logo.
-	Descripci�n: En este archivo se insertan los datos de la tabla cat�logo "departamentos".

==========================================================================================================================================================
*/


GO
EXEC r4l.sp_insert_departamento 'Direcci�n General';
EXEC r4l.sp_insert_departamento 'Subdirecci�n M�dica';
EXEC r4l.sp_insert_departamento 'Subdirecci�n Administrativa';
EXEC r4l.sp_insert_departamento 'Gesti�n de Calidad';
EXEC r4l.sp_insert_departamento 'Comit� de Bio�tica';
EXEC r4l.sp_insert_departamento 'Recursos Humanos';
EXEC r4l.sp_insert_departamento 'Finanzas';
EXEC r4l.sp_insert_departamento 'Compras';
EXEC r4l.sp_insert_departamento 'Almac�n';
EXEC r4l.sp_insert_departamento 'Tecnolog�as de la Informaci�n';
EXEC r4l.sp_insert_departamento 'Mantenimiento';
EXEC r4l.sp_insert_departamento 'Servicios Generales';
EXEC r4l.sp_insert_departamento 'Comunicaci�n Social';
EXEC r4l.sp_insert_departamento 'Archivo Cl�nico';
EXEC r4l.sp_insert_departamento 'Gobernanza Cl�nica';
EXEC r4l.sp_insert_departamento 'Consulta Externa';
EXEC r4l.sp_insert_departamento 'Hospitalizaci�n';
EXEC r4l.sp_insert_departamento 'Urgencias';
EXEC r4l.sp_insert_departamento 'Terapia Intensiva';
EXEC r4l.sp_insert_departamento 'Terapia Intermedia';
EXEC r4l.sp_insert_departamento 'Quir�fanos';
EXEC r4l.sp_insert_departamento 'Anestesiolog�a';
EXEC r4l.sp_insert_departamento 'Laboratorio Cl�nico';
EXEC r4l.sp_insert_departamento 'Imagenolog�a';
EXEC r4l.sp_insert_departamento 'Hemoterapia y Banco de Sangre';
EXEC r4l.sp_insert_departamento 'Inhaloterapia';
EXEC r4l.sp_insert_departamento 'Endoscop�a';
EXEC r4l.sp_insert_departamento 'Hemodi�lisis';
EXEC r4l.sp_insert_departamento 'Oncolog�a';
EXEC r4l.sp_insert_departamento 'Radioterapia';
EXEC r4l.sp_insert_departamento 'Nutrici�n Cl�nica';
EXEC r4l.sp_insert_departamento 'Trabajo Social';
EXEC r4l.sp_insert_departamento 'Psicolog�a Cl�nica';
EXEC r4l.sp_insert_departamento 'Farmacia Hospitalaria';
EXEC r4l.sp_insert_departamento 'Rehabilitaci�n y Fisioterapia';
EXEC r4l.sp_insert_departamento 'Medicina Preventiva';
EXEC r4l.sp_insert_departamento 'Epidemiolog�a Hospitalaria';
EXEC r4l.sp_insert_departamento 'Atenci�n al Paciente';
EXEC r4l.sp_insert_departamento 'Educaci�n para la Salud';
EXEC r4l.sp_insert_departamento 'Cuidados Paliativos';
EXEC r4l.sp_insert_departamento 'Cocina y Diet�tica';
EXEC r4l.sp_insert_departamento 'Lavander�a';
EXEC r4l.sp_insert_departamento 'Limpieza y Sanitizaci�n';
EXEC r4l.sp_insert_departamento 'Seguridad y Vigilancia';
EXEC r4l.sp_insert_departamento 'Ambulancias y Transporte';
EXEC r4l.sp_insert_departamento 'Gesti�n de Residuos Biom�dicos';
EXEC r4l.sp_insert_departamento 'Ingenier�a Biom�dica';
EXEC r4l.sp_insert_departamento 'Docencia e Investigaci�n';
EXEC r4l.sp_insert_departamento 'Residencias M�dicas';
EXEC r4l.sp_insert_departamento 'Ense�anza de Enfermer�a';
EXEC r4l.sp_insert_departamento 'Comit� de Investigaci�n';
EXEC r4l.sp_insert_departamento 'Comit� de �tica en Investigaci�n';
EXEC r4l.sp_insert_departamento 'Alergolog�a';
EXEC r4l.sp_insert_departamento 'Anestesiolog�a';
EXEC r4l.sp_insert_departamento 'Angiolog�a';
EXEC r4l.sp_insert_departamento 'Cardiolog�a';
EXEC r4l.sp_insert_departamento 'Cirug�a General';
EXEC r4l.sp_insert_departamento 'Cirug�a Pl�stica y Reconstructiva';
EXEC r4l.sp_insert_departamento 'Cirug�a Tor�cica';
EXEC r4l.sp_insert_departamento 'Cirug�a Vascular';
EXEC r4l.sp_insert_departamento 'Dermatolog�a';
EXEC r4l.sp_insert_departamento 'Endocrinolog�a';
EXEC r4l.sp_insert_departamento 'Epidemiolog�a Cl�nica';
EXEC r4l.sp_insert_departamento 'Gastroenterolog�a';
EXEC r4l.sp_insert_departamento 'Geriatr�a';
EXEC r4l.sp_insert_departamento 'Ginecolog�a y Obstetricia';
EXEC r4l.sp_insert_departamento 'Hematolog�a';
EXEC r4l.sp_insert_departamento 'Infectolog�a';
EXEC r4l.sp_insert_departamento 'Medicina del Deporte';
EXEC r4l.sp_insert_departamento 'Medicina de Urgencias';
EXEC r4l.sp_insert_departamento 'Medicina Familiar';
EXEC r4l.sp_insert_departamento 'Medicina F�sica y Rehabilitaci�n';
EXEC r4l.sp_insert_departamento 'Medicina Interna';
EXEC r4l.sp_insert_departamento 'Nefrolog�a';
EXEC r4l.sp_insert_departamento 'Neonatolog�a';
EXEC r4l.sp_insert_departamento 'Neumolog�a';
EXEC r4l.sp_insert_departamento 'Neurolog�a';
EXEC r4l.sp_insert_departamento 'Nutriolog�a Cl�nica';
EXEC r4l.sp_insert_departamento 'Oftalmolog�a';
EXEC r4l.sp_insert_departamento 'Oncolog�a M�dica';
EXEC r4l.sp_insert_departamento 'Otorrinolaringolog�a';
EXEC r4l.sp_insert_departamento 'Pediatr�a';
EXEC r4l.sp_insert_departamento 'Psiquiatr�a';
EXEC r4l.sp_insert_departamento 'Radiolog�a e Imagen';
EXEC r4l.sp_insert_departamento 'Reumatolog�a';
EXEC r4l.sp_insert_departamento 'Traumatolog�a y Ortopedia';
EXEC r4l.sp_insert_departamento 'Urolog�a';
EXEC r4l.sp_insert_departamento 'Medicina Nuclear';
EXEC r4l.sp_insert_departamento 'Gen�tica M�dica';
EXEC r4l.sp_insert_departamento 'Anatom�a Patol�gica';
EXEC r4l.sp_insert_departamento 'Cirug�a Cardiovascular';
EXEC r4l.sp_insert_departamento 'Cirug�a Maxilofacial';
EXEC r4l.sp_insert_departamento 'Cirug�a Pedi�trica';
EXEC r4l.sp_insert_departamento 'Cirug�a Oncol�gica';
EXEC r4l.sp_insert_departamento 'Cirug�a Neurol�gica';
EXEC r4l.sp_insert_departamento 'Cirug�a de Cabeza y Cuello';
EXEC r4l.sp_insert_departamento 'Cirug�a de Mano';
EXEC r4l.sp_insert_departamento 'Cirug�a de Trasplantes';
EXEC r4l.sp_insert_departamento 'Cirug�a Ortop�dica';
EXEC r4l.sp_insert_departamento 'Cirug�a Laparosc�pica';
EXEC r4l.sp_insert_departamento 'Dermatopatolog�a';
EXEC r4l.sp_insert_departamento 'Foniatr�a';
EXEC r4l.sp_insert_departamento 'Gastroenterolog�a Pedi�trica';
EXEC r4l.sp_insert_departamento 'Ginecolog�a Oncol�gica';
EXEC r4l.sp_insert_departamento 'Hepatolog�a';
EXEC r4l.sp_insert_departamento 'Inmunolog�a Cl�nica';
EXEC r4l.sp_insert_departamento 'Medicina Cr�tica';
EXEC r4l.sp_insert_departamento 'Medicina del Sue�o';
EXEC r4l.sp_insert_departamento 'Medicina Forense';
EXEC r4l.sp_insert_departamento 'Medicina Paliativa';
EXEC r4l.sp_insert_departamento 'Medicina Tropical';
EXEC r4l.sp_insert_departamento 'Microbiolog�a';
EXEC r4l.sp_insert_departamento 'Neurocirug�a';
EXEC r4l.sp_insert_departamento 'Neurofisiolog�a Cl�nica';
EXEC r4l.sp_insert_departamento 'Neuropediatr�a';
EXEC r4l.sp_insert_departamento 'Oncohematolog�a';
EXEC r4l.sp_insert_departamento 'Oncolog�a Radioter�pica';
EXEC r4l.sp_insert_departamento 'Otoneurolog�a';
EXEC r4l.sp_insert_departamento 'Patolog�a Cl�nica';
EXEC r4l.sp_insert_departamento 'Psicolog�a M�dica';
EXEC r4l.sp_insert_departamento 'Rehabilitaci�n Neurol�gica';
EXEC r4l.sp_insert_departamento 'Reumatolog�a Pedi�trica';
EXEC r4l.sp_insert_departamento 'Toxicolog�a Cl�nica';
EXEC r4l.sp_insert_departamento 'Traumatolog�a Deportiva';
EXEC r4l.sp_insert_departamento 'Urolog�a Pedi�trica';
EXEC r4l.sp_insert_departamento 'Medicina Aeroespacial';
EXEC r4l.sp_insert_departamento 'Medicina Hiperb�rica';
EXEC r4l.sp_insert_departamento 'Medicina del Dolor';
EXEC r4l.sp_insert_departamento 'Bio�tica M�dica';
EXEC r4l.sp_insert_departamento 'Telemedicina';
EXEC r4l.sp_insert_departamento 'Salud Ocupacional';
EXEC r4l.sp_insert_departamento 'Medicina Familiar y Comunitaria';
GO