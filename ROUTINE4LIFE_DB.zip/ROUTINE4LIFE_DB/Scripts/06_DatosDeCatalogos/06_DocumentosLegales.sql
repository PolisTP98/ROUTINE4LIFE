/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 06/11/2025.
-	Fecha de la �ltima actualizaci�n: 07/11/2025.
-	T�tulo: Datos de cat�logo.
-	Descripci�n: En este archivo se insertan los datos de la tabla cat�logo "documentos_legales".

==========================================================================================================================================================
*/


GO
EXEC r4l.sp_insert_documento_legal 'CURP';
EXEC r4l.sp_insert_documento_legal 'INE';
EXEC r4l.sp_insert_documento_legal 'Pasaporte Mexicano';
EXEC r4l.sp_insert_documento_legal 'Acta de Nacimiento';
EXEC r4l.sp_insert_documento_legal 'C�dula Profesional';
EXEC r4l.sp_insert_documento_legal 'T�tulo Profesional';
EXEC r4l.sp_insert_documento_legal 'Carta de Pasante';
EXEC r4l.sp_insert_documento_legal 'Certificado de Estudios (SEP)';
EXEC r4l.sp_insert_documento_legal 'RFC';
EXEC r4l.sp_insert_documento_legal 'Constancia de Situaci�n Fiscal';
EXEC r4l.sp_insert_documento_legal 'Credencial del IMSS';
EXEC r4l.sp_insert_documento_legal 'Credencial del ISSSTE';
EXEC r4l.sp_insert_documento_legal 'Licencia de Conducir';
EXEC r4l.sp_insert_documento_legal 'Cartilla Militar (SMN)';
EXEC r4l.sp_insert_documento_legal 'Carta de Naturalizaci�n Mexicana';
EXEC r4l.sp_insert_documento_legal 'Certificado de Nacionalidad Mexicana';
EXEC r4l.sp_insert_documento_legal 'C�dula de Identidad Ciudadana';
EXEC r4l.sp_insert_documento_legal 'Matr�cula Consular de Alta Seguridad';
EXEC r4l.sp_insert_documento_legal 'Credencial de Elector para Mexicanos en el Extranjero';
EXEC r4l.sp_insert_documento_legal 'Permiso de Residencia (para extranjeros)';
EXEC r4l.sp_insert_documento_legal 'Visa Mexicana (para extranjeros)';
EXEC r4l.sp_insert_documento_legal 'Comprobante de Domicilio con Fotograf�a Oficial';
EXEC r4l.sp_insert_documento_legal 'Credencial de Servidor P�blico Federal';
EXEC r4l.sp_insert_documento_legal 'Credencial de Empleado Gubernamental';
EXEC r4l.sp_insert_documento_legal 'Identificaci�n emitida por Gobierno Estatal o Municipal';
EXEC r4l.sp_insert_documento_legal 'Credencial Escolar con Fotograf�a y Sello Oficial';
EXEC r4l.sp_insert_documento_legal 'Certificado de Estudios con Fotograf�a';
EXEC r4l.sp_insert_documento_legal 'Credencial de Seguridad Privada (autorizada por la SSPC)';
EXEC r4l.sp_insert_documento_legal 'Credencial del INAPAM';
EXEC r4l.sp_insert_documento_legal 'Credencial del DIF';
EXEC r4l.sp_insert_documento_legal 'Tarjeta de Residente Temporal';
EXEC r4l.sp_insert_documento_legal 'Tarjeta de Residente Permanente';
EXEC r4l.sp_insert_documento_legal 'Identificaci�n del Instituto Nacional de Migraci�n (INM)';
EXEC r4l.sp_insert_documento_legal 'Credencial de la Secretar�a de Marina (SEMAR)';
EXEC r4l.sp_insert_documento_legal 'Credencial de la Secretar�a de la Defensa Nacional (SEDENA)';
EXEC r4l.sp_insert_documento_legal 'Constancia de Identidad Municipal';
GO