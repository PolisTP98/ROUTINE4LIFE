/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 06/11/2025.
-	Fecha de la �ltima actualizaci�n: 07/11/2025.
-	T�tulo: Datos de cat�logo.
-	Descripci�n: En este archivo se insertan los datos de la tabla cat�logo "estatus_usuarios".

==========================================================================================================================================================
*/


GO
EXEC r4l.sp_insert_estatus_usuario 'Activo';
EXEC r4l.sp_insert_estatus_usuario 'Inactivo';
EXEC r4l.sp_insert_estatus_usuario 'Suspendido';
GO