/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 06/11/2025.
-	Fecha de la �ltima actualizaci�n: 07/11/2025.
-	T�tulo: Datos de cat�logo.
-	Descripci�n: En este archivo se insertan los datos de la tabla cat�logo "comidas".

==========================================================================================================================================================
*/


GO
EXEC r4l.sp_insert_comida 'Desayuno';
EXEC r4l.sp_insert_comida 'Almuerzo';
EXEC r4l.sp_insert_comida 'Comida';
EXEC r4l.sp_insert_comida 'Merienda';
EXEC r4l.sp_insert_comida 'Cena';
EXEC r4l.sp_insert_comida 'Snack';
EXEC r4l.sp_insert_comida 'Refrigerio';
EXEC r4l.sp_insert_comida 'Postre';
GO