/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 12/11/2025.
-	Fecha de la �ltima actualizaci�n: 12/11/2025.
-	T�tulo: Procedimientos almacenados para suspender m�dicos.
-	Descripci�n: En este archivo se crean los procedimientos almacenados para suspender m�dicos de manera l�gica (pausar sus actividades temporalmente).

==========================================================================================================================================================
*/


-- STORED_PROCEDURE suspend_medico_personal
GO
CREATE OR ALTER PROCEDURE r4l.sp_suspend_medico_personal
    @id_medico INT
AS
BEGIN
    UPDATE r4l.medico_personal
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_medico = @id_medico AND id_estatus <> 3;

	UPDATE r4l.medico_laboral
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_medico = @id_medico AND id_estatus <> 3;

	UPDATE r4l.usuarios
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_medico = @id_medico AND id_estatus <> 3;
END;
GO

-- STORED_PROCEDURE suspend_medico_laboral
GO
CREATE OR ALTER PROCEDURE r4l.sp_suspend_medico_laboral
    @id_medico INT
AS
BEGIN
	UPDATE r4l.medico_laboral
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_medico = @id_medico AND id_estatus <> 3;

	UPDATE r4l.usuarios
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_medico = @id_medico AND id_estatus <> 3;
END;
GO

-- STORED_PROCEDURE suspend_usuario
GO
CREATE OR ALTER PROCEDURE r4l.sp_suspend_usuario
    @id_medico INT
AS
BEGIN
	UPDATE r4l.usuarios
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_medico = @id_medico AND id_estatus <> 3;
END;
GO