/*
==========================================================================================================================================================

-	Autor: Isaac Abdiel S�nchez L�pez.
-	Fecha de creaci�n: 12/11/2025.
-	Fecha de la �ltima actualizaci�n: 12/11/2025.
-	T�tulo: Procedimientos almacenados para suspender pacientes.
-	Descripci�n: En este archivo se crean los procedimientos almacenados para suspender pacientes de manera l�gica (pausar sus actividades temporalmente).

==========================================================================================================================================================
*/


-- STORED_PROCEDURE suspend_paciente
GO
CREATE OR ALTER PROCEDURE r4l.sp_suspend_paciente
    @id_paciente_aplicacion INT
AS
BEGIN
    UPDATE r4l.pacientes_aplicacion
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_paciente_aplicacion = @id_paciente_aplicacion AND id_estatus <> 3;

	UPDATE r4l.usuarios_pacientes
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_paciente_aplicacion = @id_paciente_aplicacion AND id_estatus <> 3;
END;
GO

-- STORED_PROCEDURE suspend_usuario_paciente
GO
CREATE OR ALTER PROCEDURE r4l.sp_suspend_usuario_paciente
    @id_paciente_aplicacion INT
AS
BEGIN
	UPDATE r4l.usuarios_pacientes
    SET id_estatus = 3,
		fecha_suspension = GETDATE()
    WHERE id_paciente_aplicacion = @id_paciente_aplicacion AND id_estatus <> 3;
END;
GO